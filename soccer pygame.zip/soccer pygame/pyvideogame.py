import pygame
from sys import exit

# BLUE ANI
def player_animationBLUE():

    global player_surfBLUE, player_indexBLUE
    player_indexBLUE += 0.1
    if player_indexBLUE >= len(player_walkBLUE): player_indexBLUE = 0
    player_surfBLUE = player_walkBLUE[int(player_indexBLUE)]



# RED ANI
def player_animation():
    global player_surf, player_index
    player_index += 0.1
    if player_index >= len(player_walk): player_index = 0
    player_surf = player_walk[int(player_index)]





pygame.init()
screen = pygame.display.set_mode((800, 400))
pygame.display.set_caption('Runner')
clock = pygame.time.Clock()
test_font = pygame.font.Font(None, 50)


bg_music = pygame.mixer.Sound('audio/backround.mp3')
bg_music.play(loops = -1)




pitch_surface = pygame.image.load('football-pitch.png').convert()
text_surface = test_font.render('My Soccer Game', False, 'Dark Blue')



# RED PLAYER
player_walk_1 = pygame.image.load('hombre-lpc5.png').convert_alpha()
player_walk_2 = pygame.image.load('hombre-lpc6.png').convert_alpha()
player_walk = [player_walk_1, player_walk_2]
player_index = 0


player_jump = pygame.image.load('hombre-lpc7.png').convert_alpha()
player_surf = player_walk[player_index]



hombre_surface = pygame.image.load('hombre-lpc9.png').convert_alpha()
hombre_x_pos = 50
hombre_y_pos = 50



# Variables for start, end, and score.
def display_score():
    global score
    score_surf = test_font.render(f'Score: {score}', False, 'Black')
    score_rect = score_surf.get_rect(center=(400, 50))
    screen.blit(score_surf, score_rect)
    return score

def start_screen():
    title_surf = test_font.render('My Soccer Game', False, 'White')
    title_rect = title_surf.get_rect(center=(400, 50))
    instructions_surf = test_font.render('Press Space to Start', False, 'White')
    instructions_rect = instructions_surf.get_rect(center=(400, 350))
    screen.blit(title_surf, title_rect)
    screen.blit(instructions_surf, instructions_rect)

def game_over_screen():
    over_surf = test_font.render('Game Over', False, 'Black')
    over_rect = over_surf.get_rect(center=(400, 200))
    restart_surf = test_font.render('Press Space to Restart', False, 'Black')
    restart_rect = restart_surf.get_rect(center=(400, 250))
    screen.blit(over_surf, over_rect)
    screen.blit(restart_surf, restart_rect)

# BLUE PLAYER
player_walk_1BLUE = pygame.image.load('hombre-lpc5BLUE.png').convert_alpha()
player_walk_2BLUE = pygame.image.load('hombre-lpc6BLUE.png').convert_alpha()
player_walkBLUE = [player_walk_1BLUE, player_walk_2BLUE]
player_indexBLUE = 0
player_surfBLUE = player_walkBLUE[player_indexBLUE]

# BALLS
ball_surface = pygame.image.load('Ball.png').convert_alpha()
ball_x_pos = 100

ball2_surface = pygame.image.load('Ball2.png').convert_alpha()
ball2_x_pos = 100

ball3_surface = pygame.image.load('Ball3.png').convert_alpha()
ball3_x_pos = 100

# RECT
hombre_surfRED = pygame.image.load('hombre-lpc8.png').convert_alpha()
hombre_rect = hombre_surfRED.get_rect(topright=(80, 320))
hombre_gravity = 0

# SPAWN POINTS
hombre_x_pos = 350
hombre_y_pos = 50
hombre_x_posBLUE = 350
hombre_y_posBLUE = 300

game_active = False
start_time = 0
score = 0

# LOOP
while True:
    game_over = False
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if event.type == pygame.MOUSEMOTION:
            if hombre_rect.collidepoint(event.pos): print('collision')
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if not game_active:
                    game_active = True
                    start_time = int(pygame.time.get_ticks() / 1000)
                    score = 0  # Reset score at the start
                    # Reset positions and states
                    hombre_x_pos = 350
                    hombre_y_pos = 50
                    hombre_x_posBLUE = 350
                    hombre_y_posBLUE = 300
                    ball_x_pos = 100
                    ball2_x_pos = 100
                    ball3_x_pos = 100
                    hombre_gravity = 0
                else:
                    hombre_gravity = -4
                    player_surf = player_jump  # Set the player to jump sprite

            if event.key == pygame.K_LEFT:
                hombre_x_pos -= 20
            if event.key == pygame.K_RIGHT:
                hombre_x_pos += 20
            if event.key == pygame.K_DOWN:
                hombre_y_pos += 10
            if event.key == pygame.K_UP:
                hombre_y_pos -= 10
            if event.key == pygame.K_a:
                hombre_x_posBLUE -= 20
            if event.key == pygame.K_d:
                hombre_x_posBLUE += 20
            if event.key == pygame.K_s:
                hombre_y_posBLUE += 10
            if event.key == pygame.K_w:
                hombre_y_posBLUE -= 10

    if game_active:
        screen.blit(pitch_surface, (0, 0))

        player_animationBLUE()
        player_animation()

        hombre_x_posBLUE += 0.5
        hombre_x_pos += 0.5

        ball_x_pos += 1.25
        ball2_x_pos += 1.25
        ball3_x_pos += 1.25

        if hombre_x_pos > 750:
            hombre_x_pos = -100
        if hombre_y_pos > 375:
            hombre_y_pos = 0
        if hombre_y_pos < -15:
            hombre_y_pos = 325

        round_pass = pygame.mixer.Sound('audio/win.mp3')

        if ball_x_pos > 800:
            ball_x_pos = -50
            round_pass.play()
            round_pass.set_volume(2.0)
            score += 1

        if ball2_x_pos > 800:
            ball2_x_pos = -50
        if ball3_x_pos > 800:
            ball3_x_pos = -50

        if hombre_x_posBLUE > 750:
            hombre_x_posBLUE = -100
        if hombre_y_posBLUE > 375:
            hombre_y_posBLUE = 0
        if hombre_y_posBLUE < -15:
            hombre_y_posBLUE = 325

        screen.blit(player_surfBLUE, (hombre_x_posBLUE, hombre_y_posBLUE))
        screen.blit(player_surf, (hombre_x_pos, hombre_y_pos))
        
        hombre_gravity += 0.01
        hombre_rect.y += hombre_gravity
        
        screen.blit(ball_surface, (ball_x_pos, 200))
        screen.blit(ball2_surface, (ball2_x_pos, 75))
        screen.blit(ball3_surface, (ball3_x_pos, 350))

        if pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball_surface.get_rect(x=ball_x_pos, y=200)) or \
           pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball2_surface.get_rect(x=ball2_x_pos, y=75)) or \
           pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball3_surface.get_rect(x=ball3_x_pos, y=350)):
            game_over = True

        if pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball_surface.get_rect(x=ball_x_pos, y=200)) or \
           pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball2_surface.get_rect(x=ball2_x_pos, y=75)) or \
           pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball3_surface.get_rect(x=ball3_x_pos, y=350)):
            game_over = True

        score = display_score()
    else:
        if score == 0:
            start_screen()
        else:
            game_over_screen()

    if game_over:
        game_active = False

    pygame.display.update()
    clock.tick(60)