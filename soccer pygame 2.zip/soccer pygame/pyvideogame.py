import pygame  
from sys import exit  

# BLUE ANI
def player_animationBLUE():
    global player_surfBLUE, player_indexBLUE  
    player_indexBLUE += 0.1
    if player_indexBLUE >= len(player_walkBLUE): player_indexBLUE = 0
    player_surfBLUE = player_walkBLUE[int(player_indexBLUE)]

# RED ANI
def player_animation():
    global player_surf, player_index  
    player_index += 0.1
    if player_index >= len(player_walk): player_index = 0
    player_surf = player_walk[int(player_index)]

pygame.init()  
screen = pygame.display.set_mode((800, 400)) #the screen size
pygame.display.set_caption('Runner')  
clock = pygame.time.Clock()  
test_font = pygame.font.Font(None, 50)  

bg_music = pygame.mixer.Sound('audio/backround.mp3') #load the background music
bg_music.play(loops = -1)  #Play the music forever

pitch_surface = pygame.image.load('football-pitch.png').convert()  
text_surface = test_font.render('My Soccer Game', False, 'Dark Blue')  

# RED PLAYER
player_walk_1 = pygame.image.load('hombre-lpc5.png').convert_alpha() 
player_walk_2 = pygame.image.load('hombre-lpc6.png').convert_alpha() 
player_walk = [player_walk_1, player_walk_2]  #Put the images together so it can animate
player_index = 0

player_jump = pygame.image.load('hombre-lpc7.png').convert_alpha()  
player_surf = player_walk[player_index]  
hombre_surface = pygame.image.load('hombre-lpc9.png').convert_alpha()
hombre_x_pos = 50
hombre_y_pos = 50

# varibles for start, end, and score.
def display_score():

    global score  #The score changes
    score_surf = test_font.render(f'Score: {score}', False, 'Black')  #the score text
    score_rect = score_surf.get_rect(center=(400, 50))  #Put the score text in the center
    screen.blit(score_surf, score_rect)  
    return score

def start_screen():
    #Start screen to begin game
    title_surf = test_font.render('My Soccer Game', False, 'White')
    title_rect = title_surf.get_rect(center=(400, 50))
    instructions_surf = test_font.render('Press Space to Start', False, 'White')
    instructions_rect = instructions_surf.get_rect(center=(400, 350))
    screen.blit(title_surf, title_rect)
    screen.blit(instructions_surf, instructions_rect)

def game_over_screen():
    #screen after you get hit
    over_surf = test_font.render('Game Over', False, 'Black')
    over_rect = over_surf.get_rect(center=(400, 200))
    restart_surf = test_font.render('Press Space to Restart', False, 'Black')
    restart_rect = restart_surf.get_rect(center=(400, 250))
    screen.blit(over_surf, over_rect)
    screen.blit(restart_surf, restart_rect)

# BLUE PLAYER
player_walk_1BLUE = pygame.image.load('hombre-lpc5BLUE.png').convert_alpha()
player_walk_2BLUE = pygame.image.load('hombre-lpc6BLUE.png').convert_alpha()
player_walkBLUE = [player_walk_1BLUE, player_walk_2BLUE]
player_indexBLUE = 0
player_surfBLUE = player_walkBLUE[player_indexBLUE]

# BALLS
ball_surface = pygame.image.load('Ball.png').convert_alpha()
ball_x_pos = 100
ball_x_speed = 1.25  #speed

ball2_surface = pygame.image.load('Ball2.png').convert_alpha()
ball2_x_pos = 100
ball2_x_speed = 1.25  #speed

ball3_surface = pygame.image.load('Ball3.png').convert_alpha()
ball3_x_pos = 100
ball3_x_speed = 1.25  #speed

ball4_surface = pygame.image.load('Ball4.png').convert_alpha()
ball4_y_pos = -50  #spawn
ball4_y_speed = 1.25  #speed

ball5_surface = pygame.image.load('Ball5.png').convert_alpha()
ball5_y_pos = -50  #spawn
ball5_y_speed = 1.25  #speed

ball6_surface = pygame.image.load('Ball6.png').convert_alpha()
ball6_y_pos = -50  #spawn
ball6_y_speed = 1.25  #speed

# RECT
hombre_surfRED = pygame.image.load('hombre-lpc8.png').convert_alpha()
hombre_rect = hombre_surfRED.get_rect(topright=(80, 320))
hombre_gravity = 0

# SPAWN POINTS
hombre_x_pos = 350
hombre_y_pos = 50
hombre_x_posBLUE = 350
hombre_y_posBLUE = 300

game_active = False
start_time = 0
score = 0

# LOOP
while True:
    game_over = False #Set game over false so it can start
    for event in pygame.event.get():  
        if event.type == pygame.QUIT:  
            pygame.quit()  
            exit() 
        if event.type == pygame.MOUSEMOTION: 
            if hombre_rect.collidepoint(event.pos): print('collision')
        if event.type == pygame.KEYDOWN:  #key pressed down
            if event.key == pygame.K_SPACE: #space key
                if not game_active: 
                    #Start the game
                    game_active = True
                    start_time = int(pygame.time.get_ticks() / 1000)
                    score = 0  #set the score to zero 
                    #the spawn points
                    hombre_x_pos = 350
                    hombre_y_pos = 50
                    hombre_x_posBLUE = 350
                    hombre_y_posBLUE = 300
                    ball_x_pos = 100
                    ball2_x_pos = 100
                    ball3_x_pos = 100
                    ball4_y_pos = -50
                    ball5_y_pos = -50
                    ball6_y_pos = -50
                    hombre_gravity = 0
                    ball_x_speed = 1.25
                    ball2_x_speed = 1.25
                    ball3_x_speed = 1.25
                    ball4_y_speed = 1.25
                    ball5_y_speed = 1.25
                    ball6_y_speed = 1.25
                else:
                    
                    hombre_gravity = -4
                    player_surf = player_jump  
            #Keyboard inputs
            if event.key == pygame.K_LEFT:
                hombre_x_pos -= 20
            if event.key == pygame.K_RIGHT:
                hombre_x_pos += 20
            if event.key == pygame.K_DOWN:
                hombre_y_pos += 10
            if event.key == pygame.K_UP:
                hombre_y_pos -= 10
            if event.key == pygame.K_a:
                hombre_x_posBLUE -= 20
            if event.key == pygame.K_d:
                hombre_x_posBLUE += 20
            if event.key == pygame.K_s:
                hombre_y_posBLUE += 10
            if event.key == pygame.K_w:
                hombre_y_posBLUE -= 10

    if game_active:
        #check if game active and run
        screen.blit(pitch_surface, (0, 0)) #create the pitch

        player_animationBLUE()  #animate the blue player
        player_animation()  #animate the red player
        

        ball_x_pos += ball_x_speed
        ball2_x_pos += ball2_x_speed
        ball3_x_pos += ball3_x_speed
        ball4_y_pos += ball4_y_speed
        ball5_y_pos += ball5_y_speed
        ball6_y_pos += ball6_y_speed
        #move the balls

        #keepthe players stay on the screen
        if hombre_x_pos > 750:
            hombre_x_pos = -100
        if hombre_y_pos > 375:
            hombre_y_pos = 0
        if hombre_y_pos < -15:
            hombre_y_pos = 325

        #Play sound when the score goes up
        round_pass = pygame.mixer.Sound('audio/win.mp3')

        #keep the balls on the screen
        if ball_x_pos > 800:
            ball_x_pos = -50
            round_pass.play()
            round_pass.set_volume(2.0)
            score += 1
            # up the score after every round
            ball_x_speed += 0.25  #increase speed by 0.25 every round
            ball2_x_speed += 0.25
            ball3_x_speed += 0.25

        if ball2_x_pos > 800:
            ball2_x_pos = -50
        if ball3_x_pos > 800:
            ball3_x_pos = -50


        # Keep the players on the screen
        if hombre_x_posBLUE > 750:
            hombre_x_posBLUE = -100
        if hombre_y_posBLUE > 375:
            hombre_y_posBLUE = 0
        if hombre_y_posBLUE < -15:
            hombre_y_posBLUE = 325

        #load everything
        screen.blit(player_surfBLUE, (hombre_x_posBLUE, hombre_y_posBLUE))
        screen.blit(player_surf, (hombre_x_pos, hombre_y_pos))
        
        hombre_gravity += 0.01
        hombre_rect.y += hombre_gravity
        
        screen.blit(ball_surface, (ball_x_pos, 200))
        screen.blit(ball2_surface, (ball2_x_pos, 75))
        screen.blit(ball3_surface, (ball3_x_pos, 350))

        # Bring in other balls after round 10
        if score >= 10 and ball4_y_pos < 400:  #after score = 10
            screen.blit(ball4_surface, (ball4_y_pos, 300))
        elif score >= 10:  #else condition to reset ball4
            ball4_y_pos = -50

        if score >= 20 and ball5_y_pos < 400:  #after score = 20 add another ball
            screen.blit(ball5_surface, (ball5_y_pos, 150))
        elif score >= 20:  #else condition to reset ball5
            ball5_y_pos = -50

        if score >= 30 and ball6_y_pos < 400:  #after 30 bring in final ball
            screen.blit(ball6_surface, (ball6_y_pos, 225))
        elif score >= 30: #else condition to reset ball6
            ball6_y_pos = -50

        #check if the players hit a ball
        if pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball_surface.get_rect(x=ball_x_pos, y=200)) or \
           pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball2_surface.get_rect(x=ball2_x_pos, y=75)) or \
           pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball3_surface.get_rect(x=ball3_x_pos, y=350)):
            game_over = True

        if pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball_surface.get_rect(x=ball_x_pos, y=200)) or \
           pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball2_surface.get_rect(x=ball2_x_pos, y=75)) or \
           pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball3_surface.get_rect(x=ball3_x_pos, y=350)):
            game_over = True

        #check if the added balls hit the players
        if score >= 10 and pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball4_surface.get_rect(x=ball4_y_pos, y=300)):
            game_over = True
        if score >= 20 and pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball5_surface.get_rect(x=ball5_y_pos, y=150)):
            game_over = True
        if score >= 30 and pygame.Rect(hombre_x_posBLUE, hombre_y_posBLUE, player_surfBLUE.get_width(), player_surfBLUE.get_height()).colliderect(ball6_surface.get_rect(x=ball6_y_pos, y=225)):
            game_over = True

        if score >= 10 and pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball4_surface.get_rect(x=ball4_y_pos, y=300)):
            game_over = True
        if score >= 20 and pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball5_surface.get_rect(x=ball5_y_pos, y=150)):
            game_over = True
        if score >= 30 and pygame.Rect(hombre_x_pos, hombre_y_pos, player_surf.get_width(), player_surf.get_height()).colliderect(ball6_surface.get_rect(x=ball6_y_pos, y=225)):
            game_over = True

        score = display_score()
    else:
        #Show the start and Game over screens
        if score == 0:
            start_screen()
        else:
            game_over_screen()

    if game_over:
        game_active = False

    pygame.display.update()  
    clock.tick(60)  